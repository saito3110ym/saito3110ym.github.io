var greeting = 'Hellow World';
console.log(greeting);

let frowers = ['tulip','carnation','violet'];
console.log(frowers)

for ( let i =0; i<frowers.length; i++ ){

  console.log(frowers[i]);
  
}